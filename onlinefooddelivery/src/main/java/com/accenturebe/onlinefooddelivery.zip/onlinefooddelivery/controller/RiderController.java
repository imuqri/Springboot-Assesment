package com.accenturebe.onlinefooddelivery.controller;

public class RiderController {
}
